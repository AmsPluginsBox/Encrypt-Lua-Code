
function TestLuaEncrypt()

t = [[
Hello world, LUA Encrypt version trial.
https://www.facebook.com/AmsPluginsBox/
whatsapp=85996583133
]]
print(t);


end

TestLuaEncrypt();


