
pcall(package.loadlib("AmsLuac.dll", "irPlg_Action_RegisterActions"));

AmsLuac.LoadFile("LuaEncrypt.cl");


TestLuaEncrypt();


